//>>built
define("dojo/data/api/Item",["../../_base/declare"],function(_1){return _1(null,{});});